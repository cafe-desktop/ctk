/* cdkconfig.h
 *
 * This is a generated file.  Please modify `configure.ac'
 */

#ifndef __CDKCONFIG_H__
#define __CDKCONFIG_H__

#if !defined (__CDK_H_INSIDE__) && !defined (CDK_COMPILATION)
#error "Only <cdk/cdk.h> can be included directly."
#endif

#include <glib.h>

G_BEGIN_DECLS


#define CDK_WINDOWING_X11
#define CDK_WINDOWING_BROADWAY
#define CDK_WINDOWING_WAYLAND

G_END_DECLS

#endif  /* __CDKCONFIG_H__ */
